# ITMO.Maps project
#### Made for android y2017 course in ITMO

## Information
Map for ITMO's Main Building with features.  
1. Building route from one room(place or lecture hall) to another  
2. Leaving comments for other students  

## Tasks
1. Create app's basic architecture 
